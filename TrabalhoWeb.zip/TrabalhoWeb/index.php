<?php
session_start();

// Inclui as credenciais de conexão (deixe este arquivo fora do htdocs por segurança)
require('credenciais.php');

// Conecta ao MySQL (sem especificar banco inicialmente)
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Cria o banco de dados
$sql = "CREATE DATABASE IF NOT EXISTS trabalhoFinal";
if (mysqli_query($conn, $sql)) {
  #  echo "Database 'trabalhoFinal' created successfully<br>";
} else {
    echo "Error creating database: " . mysqli_error($conn) . "<br>";
}

// Seleciona o banco de dados
mysqli_select_db($conn, 'trabalhoFinal');

// Cria a tabela USER
$sql = "CREATE TABLE IF NOT EXISTS USER (
    nome VARCHAR(50) NOT NULL PRIMARY KEY,
    senha VARCHAR(50) NOT NULL,
    pontos INT
)";
if (mysqli_query($conn, $sql)) {
 #  echo "Table 'USER' created successfully<br>";
} else {
    echo "Error creating table: " . mysqli_error($conn) . "<br>";
}

/*
    // SQL para dropar a tabela (usar apenas se for necessário alterar a estrutura da tabela)
    // **DEIXAR COMENTADO SEMPRE, PELO AMOR DE DEUS**
    $sql = "DROP TABLE IF EXISTS USER";
    if (mysqli_query($conn, $sql)) {
        echo "Tabela 'USER' excluída com sucesso.";
    } else {
        echo "Erro ao excluir tabela: " . mysqli_error($conn);
    }
*/

// Fechar conexão
mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Trabalho WEB </title>
    <link rel="stylesheet" href="styles/styleGeral.css">
    <link rel="stylesheet" href="styles/styleJogoFim.css">
    <link rel="stylesheet" href="styles/styleJogoGeral.css">
    <link rel="stylesheet" href="styles/styleJogoImagem.css">
    <link rel="stylesheet" href="styles/styleJogoIniciar.css">
    <link rel="stylesheet" href="styles/styleJogoRespostas.css">
</head>
<body class="main">
    <div class="header">
        <h4>Jogo das Imagens</h4>
    </div>
    <div class="container">
        <!--Corpo do jogo-->
        <div class="jogo">
            <!--Jogo--> 
            <div class="iniciar_regras" id="pgIni">
                <div class="regras">
                    <p>
                        Selecione uma dificuldade e clique em iniciar, 
                        você vai ter um tempo limite para visualizar e ela sumirá em seguida, 
                        então escreva o maximo de palavras que puder para ganhar pontos
                    </p>
                </div>
                <div class="iniciar">
                        <label for="dificuldade">Defina a dificulade</label>
                        <div class="selecaoDificuldade">
                            <p >0.2s</p>
                            <input type="range" id="nivel" name="dificuldade" min="2" max="10">
                            <p >1s</p>
                        </div>          
                    <button id="iniciar">Iniciar</button>
                </div>
            </div>
            <div class="imagem" id="pgImg">
                <img id="imagem" src="https://picsum.photos/1920/1080?random=<?= rand() ?>" alt="Imagem aleatória">
                <div class="cronometro">
                    <p>TEMPO: <span id="cronometro">10</span></p>   
                </div>
            </div>
            <div class="respostas" id="pgResp">
                <h4>Digite!:</h4>
                <div class="quadro" id="quadro">
                   
                  <!--<p class="certo">Garfo</p>
                    <p class="errado">Garfo</p>   -->  
                </div>
                <div class="input_contador">
                    <input type="text" class="inputRespostas" id="input_respostas">
                    <p id="contador">0</p>
                </div>
            </div>
            <div class="fim" id="pgFim">
                <p><span id="jogador"></span>, pontuação: <span id="pontuaçãoFinal"></span></p>
                <button id="jogarNovamente">Jogar novamente</button>
            </div>
        </div>
        <div class="leaderboard">
            <!--Leadearboard-->
            <h4>Leaderboard</h4>
            <div class="cards">
                <!--
                <div class="card">
                    <p class="posição"><span id="posicao">1</span>&deg</p>
                    <div class="jogador">
                        <p>Gerson Bel</p>
                        <p>1000000000</p>
                    </div>
                </div>
                <div class="card">
                    <p class="posição"><span id="posicao">1</span>&deg</p>
                    <div class="jogador">
                        <p>Gerson Bel</p>
                        <p>1000000000</p>
                    </div>
                </div> 
                -->
                
            </div>
        </div>
    </div>
    <div class="footer">
        <!--FOOTER-->
        <h5>Responsaveis:</h5>
        <p>Gerson Belniowski - GRR20240439</p>
        <p>João Victor Timoteo - GRR20246658</p>
        <p>Juliano Vidal - GRR2024</p>
        <p>Roberto Rigo - GRR20240574</p>
    </div>
    
    <script src="scripts/scriptVars.js"></script>
    <script src="scripts/scriptPontuando.js"></script>
    <script src="scripts/scriptJogo.js"></script>
    <script src="scripts/scriptInicioFim.js"></script>
    
</body>
</html>