/*--------------------------------------------*/
/* Pontuando */

function pontuando() {
    pontosRecebidos = 10/tempoImg;
    pontos = pontosRecebidos;
};

function limpar() {
    INSTXTQUADRO.innerHTML = "";
}

function respondendo() {
    resposta = INPRESPOSTAS.value;

    const p = document.createElement("p");
    p.textContent = resposta;
    p.className = arrayRespostas.includes(resposta.toLowerCase()) ? "certo" : "errado";

    if (arrayRespostas.includes(resposta.toLowerCase())) {
        pontuando();
        let indice = arrayRespostas.indexOf(resposta);
        arrayRespostas.splice(indice, 1);
    }

    INSTXTQUADRO.appendChild(p);
}

INPRESPOSTAS.addEventListener("keydown", ()=>{
    if (event.key === "Enter") {
        respondendo();
        INPRESPOSTAS.value = "";
    }
})