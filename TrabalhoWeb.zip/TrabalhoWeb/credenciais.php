<?php
    $servername = "localhost";
    $username = "root";
    $password = "junior32";
    $dbname = "trabalhoFinal";
?>